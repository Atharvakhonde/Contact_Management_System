package com.contactmanagement.contact_management_system;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Base configuration for Spring
 */
@Configuration
@ComponentScan("com.contactmanagement.contact_management_system")
public class AppSpringConfig {
}
