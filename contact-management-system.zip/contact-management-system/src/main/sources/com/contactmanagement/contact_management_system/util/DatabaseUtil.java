package com.contactmanagement.contact_management_system.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {

    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/contact_management";
    private static final String USER = "root";
    private static final String PASSWORD = "yourpassword";

    // Utility method to get a database connection
    public static Connection getConnection() throws SQLException {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found!");
            e.printStackTrace();
            throw new SQLException("Unable to load database driver.");
        }

        // Establish and return a connection
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Utility method to close the connection
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Error closing the database connection.");
                e.printStackTrace();
            }
        }
    }
}