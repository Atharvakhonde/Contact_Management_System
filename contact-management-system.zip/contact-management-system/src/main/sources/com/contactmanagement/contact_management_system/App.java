package com.contactmanagement.contact_management_system; // Correct package declaration
import com.contactmanagement.util.DatabaseUtil;
/**
 * Hello world!
 */
public class App 
{
    public static void main(String[] args)
    {
        System.out.println("Hello World!");
    }
}
